package com.guru.springsecuritydemo.role;

public interface Role {
	String EMPLOYEE="EMPLOYEE";
	String MANAGER="MANAGER";
	String ADMIN="ADMIN";
}
